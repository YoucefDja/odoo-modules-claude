Open ERP System :- Odoo 15.0 Branch 

Installation 
============
Install the Application => Apps -> Signup With Mobile Number(Technical Name:signup_with_phone)


Version
========
Odoo v15

Configuration Guideline
=============================

1.  Upon installation of module, necessary configurations will be automatically set like.
    Free Account(b2c) will be enabled in Settings -> General Settings -> Custom Account
    Employee rights will be assigned if user is of type Portal.Sign up/ Registration form
